# Ocean Product Sharing [![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)

**Contributors:** Nick  
**Requires at least:** WordPress 4.4  
**Tested up to:** WordPress 4.9.1  
**Stable tag:** 1.0.5  
**License:** GPLv2 or later  
**License URI:** http://www.gnu.org/licenses/gpl-2.0.html  

## Description

A simple plugin to add social share buttons to your product page.
This plugin requires the [OceanWP](https://oceanwp.org/) theme to be installed.